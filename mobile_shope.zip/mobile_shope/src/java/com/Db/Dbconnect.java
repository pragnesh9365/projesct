package com.Db;

import java.sql.*;

public class Dbconnect {

    private static Connection conn = null;

    public static Connection getconnection() {
        if (conn == null)
        {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver"); // This loads the MySQL driver class  
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping-cart","root", "9365");
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return conn ;
    }
}
